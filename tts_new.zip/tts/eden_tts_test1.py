import requests
import json
import base64
import os

API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiNGFkZDc2MjYtN2I2Mi00MjFkLWE5M2ItMTdjZTg5NjFhZDgyIiwidHlwZSI6ImFwaV90b2tlbiJ9.M4KOmwPJ89BTBTO0N7wGuPnZlsKvAWvZumNhlW8ImNw"
OUTPUT_FILE = "tts_output_microsoft_farid.mp3"

text_to_speak = "سلام من امیر علی قشنگی هستم . این متن برای تست ابزار متن به گفتار است امروز سه شنبه 20 آبان ماه سال 1404 است ."
url = "https://api.edenai.run/v2/audio/text_to_speech"

headers = {
    "Authorization": f"Bearer {API_KEY}",
    "Content-Type": "application/json"
}

data = {
    "providers": "microsoft",
    "language": "fa-IR",
    "text": text_to_speak,
    "option": "fa-IR-FaridNeural"
}

print("🚀 بازگشت به Microsoft Azure و ارسال درخواست...")
response = requests.post(url, headers=headers, data=json.dumps(data))

if response.status_code == 200:
    response_data = response.json()
    audio_b64 = response_data['microsoft']['audio']

    import base64
    audio_content = base64.b64decode(audio_b64)

    with open(OUTPUT_FILE, "wb") as f:
        f.write(audio_content)

    print(
        f"\n موفقیت! فایل صوتی با صدای FaridNeural در '{OUTPUT_FILE}' ذخیره شد.")

else:
    print(
        f"\n خطای غیرمنتظره در Microsoft. Status Code: {response.status_code}")
    print(f"Error Response Text: {response.text}")
